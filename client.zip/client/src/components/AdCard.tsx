import { Link } from "wouter";
import { MapPin, Clock } from "lucide-react";
import { type Ad } from "@shared/schema";
import { formatDistanceToNow } from "date-fns";

interface AdCardProps {
  ad: Ad;
  actions?: React.ReactNode;
}

export function AdCard({ ad, actions }: AdCardProps) {
  return (
    <div className="group bg-card border border-border/50 rounded-3xl overflow-hidden shadow-sm hover:shadow-xl transition-all duration-300">
      <Link href={`/ad/${ad.id}`} className="block relative aspect-[4/3] overflow-hidden bg-muted">
        {ad.imageUrl ? (
          <img 
            src={ad.imageUrl} 
            alt={ad.title} 
            className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-500"
          />
        ) : (
          <div className="w-full h-full flex items-center justify-center text-muted-foreground bg-secondary">
            No image
          </div>
        )}
        <div className="absolute top-3 right-3 bg-background/90 backdrop-blur text-foreground px-3 py-1 rounded-full text-xs font-semibold shadow-sm">
          {ad.category}
        </div>
      </Link>
      
      <div className="p-4 flex flex-col space-y-2">
        <div className="flex justify-between items-start gap-4">
          <Link href={`/ad/${ad.id}`} className="block">
            <h3 className="font-display font-bold text-lg text-foreground line-clamp-1 group-hover:text-primary transition-colors">
              {ad.title}
            </h3>
          </Link>
          <span className="font-display font-extrabold text-primary shrink-0">
            ${Number(ad.price).toLocaleString()}
          </span>
        </div>
        
        <div className="flex items-center text-xs text-muted-foreground gap-4">
          <div className="flex items-center gap-1">
            <MapPin className="w-3.5 h-3.5" />
            <span className="truncate max-w-[100px]">{ad.location}</span>
          </div>
          <div className="flex items-center gap-1">
            <Clock className="w-3.5 h-3.5" />
            <span>{ad.createdAt ? formatDistanceToNow(new Date(ad.createdAt)) : 'Just now'}</span>
          </div>
        </div>

        {actions && (
          <div className="pt-3 mt-2 border-t border-border/50 flex gap-2">
            {actions}
          </div>
        )}
      </div>
    </div>
  );
}
