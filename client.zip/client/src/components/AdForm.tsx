import { useState } from "react";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { z } from "zod";
import { api } from "@shared/routes";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Label } from "@/components/ui/label";
import { ImagePlus, Loader2, X } from "lucide-react";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { useToast } from "@/hooks/use-toast";

const formSchema = api.ads.create.input;
type FormValues = z.infer<typeof formSchema>;

const CATEGORIES = ["Electronics", "Vehicles", "Real Estate", "Furniture", "Services", "Other"];

interface AdFormProps {
  defaultValues?: Partial<FormValues>;
  onSubmit: (data: FormValues) => void;
  isLoading: boolean;
  submitLabel: string;
}

export function AdForm({ defaultValues, onSubmit, isLoading, submitLabel }: AdFormProps) {
  const { toast } = useToast();
  const [imagePreview, setImagePreview] = useState<string | null>(defaultValues?.imageUrl || null);
  
  const form = useForm<FormValues>({
    resolver: zodResolver(formSchema),
    defaultValues: {
      title: defaultValues?.title || "",
      description: defaultValues?.description || "",
      price: defaultValues?.price || "",
      category: defaultValues?.category || "",
      location: defaultValues?.location || "",
      imageUrl: defaultValues?.imageUrl || null,
    },
  });

  const handleImageChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    if (file.size > 1024 * 1024) {
      toast({ title: "File too large", description: "Image must be under 1MB", variant: "destructive" });
      return;
    }

    const reader = new FileReader();
    reader.onloadend = () => {
      const base64 = reader.result as string;
      setImagePreview(base64);
      form.setValue("imageUrl", base64);
    };
    reader.readAsDataURL(file);
  };

  return (
    <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-6">
      <div className="space-y-2">
        <Label>Photo (Max 1MB)</Label>
        <div className="relative">
          {imagePreview ? (
            <div className="relative aspect-video rounded-2xl overflow-hidden border border-border">
              <img src={imagePreview} alt="Preview" className="w-full h-full object-cover" />
              <button
                type="button"
                onClick={() => {
                  setImagePreview(null);
                  form.setValue("imageUrl", null);
                }}
                className="absolute top-2 right-2 p-2 bg-background/80 backdrop-blur rounded-full hover:bg-destructive hover:text-destructive-foreground transition-colors"
              >
                <X className="w-4 h-4" />
              </button>
            </div>
          ) : (
            <label className="flex flex-col items-center justify-center w-full aspect-video border-2 border-dashed border-border rounded-2xl cursor-pointer hover:bg-secondary/50 transition-colors">
              <div className="flex flex-col items-center justify-center pt-5 pb-6 text-muted-foreground">
                <ImagePlus className="w-10 h-10 mb-3" />
                <p className="text-sm font-medium">Click to upload photo</p>
              </div>
              <input type="file" className="hidden" accept="image/*" onChange={handleImageChange} />
            </label>
          )}
        </div>
      </div>

      <div className="space-y-2">
        <Label htmlFor="title">Title</Label>
        <Input 
          id="title" 
          placeholder="What are you selling?" 
          className="rounded-xl h-12"
          {...form.register("title")} 
        />
        {form.formState.errors.title && <p className="text-xs text-destructive">{form.formState.errors.title.message}</p>}
      </div>

      <div className="grid grid-cols-2 gap-4">
        <div className="space-y-2">
          <Label htmlFor="price">Price ($)</Label>
          <Input 
            id="price" 
            type="number" 
            step="0.01" 
            placeholder="0.00" 
            className="rounded-xl h-12"
            {...form.register("price")} 
          />
          {form.formState.errors.price && <p className="text-xs text-destructive">{form.formState.errors.price.message}</p>}
        </div>

        <div className="space-y-2">
          <Label>Category</Label>
          <Select 
            value={form.watch("category")} 
            onValueChange={(val) => form.setValue("category", val)}
          >
            <SelectTrigger className="rounded-xl h-12">
              <SelectValue placeholder="Select..." />
            </SelectTrigger>
            <SelectContent>
              {CATEGORIES.map(cat => (
                <SelectItem key={cat} value={cat}>{cat}</SelectItem>
              ))}
            </SelectContent>
          </Select>
          {form.formState.errors.category && <p className="text-xs text-destructive">{form.formState.errors.category.message}</p>}
        </div>
      </div>

      <div className="space-y-2">
        <Label htmlFor="location">Location</Label>
        <Input 
          id="location" 
          placeholder="City, Neighborhood" 
          className="rounded-xl h-12"
          {...form.register("location")} 
        />
        {form.formState.errors.location && <p className="text-xs text-destructive">{form.formState.errors.location.message}</p>}
      </div>

      <div className="space-y-2">
        <Label htmlFor="description">Description</Label>
        <Textarea 
          id="description" 
          placeholder="Describe your item in detail..." 
          className="rounded-xl min-h-[120px] resize-none"
          {...form.register("description")} 
        />
        {form.formState.errors.description && <p className="text-xs text-destructive">{form.formState.errors.description.message}</p>}
      </div>

      <Button 
        type="submit" 
        className="w-full h-14 rounded-xl text-lg font-bold shadow-lg shadow-primary/25 hover:-translate-y-0.5 transition-all"
        disabled={isLoading}
      >
        {isLoading ? <Loader2 className="w-5 h-5 animate-spin mr-2" /> : null}
        {submitLabel}
      </Button>
    </form>
  );
}
