import { BottomNav } from "./BottomNav";

interface AppLayoutProps {
  children: React.ReactNode;
  hideNav?: boolean;
}

export function AppLayout({ children, hideNav = false }: AppLayoutProps) {
  return (
    <div className="min-h-screen bg-secondary/30 text-foreground font-sans selection:bg-primary/20">
      <div className="max-w-2xl mx-auto min-h-screen bg-background shadow-2xl relative flex flex-col">
        <div className={`flex-1 flex flex-col ${!hideNav ? "pb-24" : ""}`}>
          {children}
        </div>
        {!hideNav && <BottomNav />}
      </div>
    </div>
  );
}
