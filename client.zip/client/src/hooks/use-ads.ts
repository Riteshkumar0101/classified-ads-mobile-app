import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { api, buildUrl } from "@shared/routes";
import { apiRequest } from "@/lib/queryClient";
import { z } from "zod";
import { useToast } from "@/hooks/use-toast";

type CreateAdInput = z.infer<typeof api.ads.create.input>;
type UpdateAdInput = z.infer<typeof api.ads.update.input>;

export function useAds(search?: string, category?: string) {
  const params = new URLSearchParams();
  if (search) params.append("search", search);
  if (category) params.append("category", category);
  
  const queryStr = params.toString() ? `?${params.toString()}` : "";
  const url = `${api.ads.list.path}${queryStr}`;

  return useQuery({
    queryKey: [api.ads.list.path, search, category],
    queryFn: async () => {
      const res = await apiRequest("GET", url);
      return api.ads.list.responses[200].parse(await res.json());
    },
  });
}

export function useMyAds() {
  return useQuery({
    queryKey: [api.ads.myAds.path],
    queryFn: async () => {
      const res = await apiRequest("GET", api.ads.myAds.path);
      return api.ads.myAds.responses[200].parse(await res.json());
    },
  });
}

export function useAd(id: number) {
  return useQuery({
    queryKey: [api.ads.get.path, id],
    queryFn: async () => {
      const url = buildUrl(api.ads.get.path, { id });
      const res = await apiRequest("GET", url);
      return api.ads.get.responses[200].parse(await res.json());
    },
    enabled: !!id,
  });
}

export function useCreateAd() {
  const queryClient = useQueryClient();
  const { toast } = useToast();

  return useMutation({
    mutationFn: async (data: CreateAdInput) => {
      const res = await apiRequest("POST", api.ads.create.path, data);
      return api.ads.create.responses[201].parse(await res.json());
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: [api.ads.list.path] });
      queryClient.invalidateQueries({ queryKey: [api.ads.myAds.path] });
      toast({ title: "Success!", description: "Your ad has been posted." });
    },
    onError: (err: Error) => {
      toast({ title: "Failed to post ad", description: err.message, variant: "destructive" });
    }
  });
}

export function useUpdateAd(id: number) {
  const queryClient = useQueryClient();
  const { toast } = useToast();

  return useMutation({
    mutationFn: async (data: UpdateAdInput) => {
      const url = buildUrl(api.ads.update.path, { id });
      const res = await apiRequest("PUT", url, data);
      return api.ads.update.responses[200].parse(await res.json());
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: [api.ads.list.path] });
      queryClient.invalidateQueries({ queryKey: [api.ads.myAds.path] });
      queryClient.invalidateQueries({ queryKey: [api.ads.get.path, id] });
      toast({ title: "Updated!", description: "Your ad has been updated." });
    },
    onError: (err: Error) => {
      toast({ title: "Update failed", description: err.message, variant: "destructive" });
    }
  });
}

export function useDeleteAd() {
  const queryClient = useQueryClient();
  const { toast } = useToast();

  return useMutation({
    mutationFn: async (id: number) => {
      const url = buildUrl(api.ads.delete.path, { id });
      await apiRequest("DELETE", url);
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: [api.ads.list.path] });
      queryClient.invalidateQueries({ queryKey: [api.ads.myAds.path] });
      toast({ title: "Deleted", description: "Your ad has been removed." });
    },
    onError: (err: Error) => {
      toast({ title: "Delete failed", description: err.message, variant: "destructive" });
    }
  });
}
