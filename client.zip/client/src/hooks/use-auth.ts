import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { api } from "@shared/routes";
import { apiRequest } from "@/lib/queryClient";
import { z } from "zod";
import { useLocation } from "wouter";
import { useToast } from "@/hooks/use-toast";

type UserInput = z.infer<typeof api.auth.login.input>;
type AuthResponse = z.infer<typeof api.auth.login.responses[200]>;
type MeResponse = z.infer<typeof api.auth.me.responses[200]>;

export function useUser() {
  return useQuery({
    queryKey: [api.auth.me.path],
    queryFn: async () => {
      if (!localStorage.getItem("token")) return null;
      try {
        const res = await apiRequest("GET", api.auth.me.path);
        return api.auth.me.responses[200].parse(await res.json());
      } catch (e) {
        localStorage.removeItem("token");
        return null;
      }
    },
  });
}

export function useLogin() {
  const queryClient = useQueryClient();
  const [, setLocation] = useLocation();
  const { toast } = useToast();

  return useMutation({
    mutationFn: async (data: UserInput) => {
      const res = await apiRequest("POST", api.auth.login.path, data);
      return api.auth.login.responses[200].parse(await res.json());
    },
    onSuccess: (data) => {
      localStorage.setItem("token", data.token);
      queryClient.setQueryData([api.auth.me.path], data.user);
      setLocation("/");
      toast({ title: "Welcome back!", description: "Logged in successfully." });
    },
    onError: (err: Error) => {
      toast({ title: "Login failed", description: err.message, variant: "destructive" });
    }
  });
}

export function useRegister() {
  const queryClient = useQueryClient();
  const [, setLocation] = useLocation();
  const { toast } = useToast();

  return useMutation({
    mutationFn: async (data: UserInput) => {
      const res = await apiRequest("POST", api.auth.register.path, data);
      return api.auth.register.responses[201].parse(await res.json());
    },
    onSuccess: (data) => {
      localStorage.setItem("token", data.token);
      queryClient.setQueryData([api.auth.me.path], data.user);
      setLocation("/");
      toast({ title: "Account created!", description: "Welcome to Classifieds." });
    },
    onError: (err: Error) => {
      toast({ title: "Registration failed", description: err.message, variant: "destructive" });
    }
  });
}

export function useLogout() {
  const queryClient = useQueryClient();
  const [, setLocation] = useLocation();
  const { toast } = useToast();

  return () => {
    localStorage.removeItem("token");
    queryClient.setQueryData([api.auth.me.path], null);
    setLocation("/login");
    toast({ title: "Logged out", description: "See you next time!" });
  };
}
