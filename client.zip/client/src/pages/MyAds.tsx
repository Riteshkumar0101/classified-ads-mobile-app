import { AppLayout } from "@/components/AppLayout";
import { useMyAds, useDeleteAd } from "@/hooks/use-ads";
import { AdCard } from "@/components/AdCard";
import { Button } from "@/components/ui/button";
import { Edit2, Trash2, Loader2, PackageOpen } from "lucide-react";
import { motion } from "framer-motion";
import { useLocation } from "wouter";
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
  AlertDialogTrigger,
} from "@/components/ui/alert-dialog";

export default function MyAds() {
  const { data: ads, isLoading } = useMyAds();
  const deleteAd = useDeleteAd();
  const [, setLocation] = useLocation();

  return (
    <AppLayout>
      <div className="px-6 pt-12 pb-6 flex-1 flex flex-col">
        <h1 className="font-display text-3xl font-extrabold tracking-tight mb-8">My Ads</h1>

        {isLoading ? (
          <div className="flex-1 flex flex-col items-center justify-center">
            <Loader2 className="w-8 h-8 animate-spin text-primary mb-4" />
          </div>
        ) : ads?.length === 0 ? (
          <div className="flex-1 flex flex-col items-center justify-center text-center pb-20">
            <div className="w-24 h-24 bg-secondary rounded-[2rem] flex items-center justify-center mb-6 rotate-3">
              <PackageOpen className="w-12 h-12 text-muted-foreground -rotate-3" />
            </div>
            <h3 className="font-display font-bold text-2xl mb-2">No ads yet</h3>
            <p className="text-muted-foreground mb-8">You haven't posted any items for sale.</p>
            <Button 
              onClick={() => setLocation("/add")}
              className="rounded-xl px-8 h-12 text-base shadow-lg shadow-primary/20"
            >
              Post your first ad
            </Button>
          </div>
        ) : (
          <div className="grid grid-cols-1 gap-6 pb-6">
            {ads?.map((ad, idx) => (
              <motion.div
                key={ad.id}
                initial={{ opacity: 0, x: -20 }}
                animate={{ opacity: 1, x: 0 }}
                transition={{ delay: idx * 0.1 }}
              >
                <AdCard 
                  ad={ad} 
                  actions={
                    <>
                      <Button 
                        variant="secondary" 
                        className="flex-1 rounded-xl h-10"
                        onClick={() => setLocation(`/edit/${ad.id}`)}
                      >
                        <Edit2 className="w-4 h-4 mr-2" /> Edit
                      </Button>
                      <AlertDialog>
                        <AlertDialogTrigger asChild>
                          <Button 
                            variant="destructive" 
                            className="flex-1 rounded-xl h-10 bg-destructive/10 text-destructive hover:bg-destructive hover:text-white"
                          >
                            <Trash2 className="w-4 h-4 mr-2" /> Delete
                          </Button>
                        </AlertDialogTrigger>
                        <AlertDialogContent className="rounded-3xl w-[90%] max-w-sm">
                          <AlertDialogHeader>
                            <AlertDialogTitle className="font-display">Delete Ad?</AlertDialogTitle>
                            <AlertDialogDescription>
                              This action cannot be undone. This will permanently delete your ad.
                            </AlertDialogDescription>
                          </AlertDialogHeader>
                          <AlertDialogFooter className="flex-col gap-2 sm:flex-row mt-4">
                            <AlertDialogCancel className="rounded-xl h-12 m-0">Cancel</AlertDialogCancel>
                            <AlertDialogAction 
                              onClick={() => deleteAd.mutate(ad.id)}
                              className="rounded-xl h-12 m-0 bg-destructive text-destructive-foreground hover:bg-destructive/90"
                            >
                              Yes, delete
                            </AlertDialogAction>
                          </AlertDialogFooter>
                        </AlertDialogContent>
                      </AlertDialog>
                    </>
                  }
                />
              </motion.div>
            ))}
          </div>
        )}
      </div>
    </AppLayout>
  );
}
