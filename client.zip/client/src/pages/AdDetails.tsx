import { AppLayout } from "@/components/AppLayout";
import { useAd } from "@/hooks/use-ads";
import { ArrowLeft, MapPin, Tag, User, Loader2, MessageCircle } from "lucide-react";
import { useLocation } from "wouter";
import { Button } from "@/components/ui/button";
import { formatDistanceToNow } from "date-fns";
import { motion } from "framer-motion";

export default function AdDetails({ params }: { params: { id: string } }) {
  const [, setLocation] = useLocation();
  const { data: ad, isLoading } = useAd(parseInt(params.id));

  if (isLoading) {
    return (
      <AppLayout hideNav>
        <div className="flex items-center justify-center h-screen pb-20">
          <Loader2 className="w-8 h-8 animate-spin text-primary" />
        </div>
      </AppLayout>
    );
  }

  if (!ad) {
    return (
      <AppLayout hideNav>
        <div className="flex flex-col items-center justify-center h-screen pb-20 text-center px-6">
          <h2 className="font-display text-2xl font-bold mb-2">Ad not found</h2>
          <p className="text-muted-foreground mb-6">The item you're looking for doesn't exist or was removed.</p>
          <Button onClick={() => setLocation("/")} className="rounded-xl h-12 px-8">
            Go Back Home
          </Button>
        </div>
      </AppLayout>
    );
  }

  return (
    <AppLayout hideNav>
      <div className="relative bg-background min-h-screen">
        {/* Header/Image */}
        <div className="relative h-[40vh] bg-muted">
          <button 
            onClick={() => setLocation("/")}
            className="absolute top-6 left-6 z-10 w-10 h-10 bg-background/80 backdrop-blur rounded-full flex items-center justify-center shadow-lg hover:bg-background transition-colors"
          >
            <ArrowLeft className="w-5 h-5" />
          </button>
          
          {ad.imageUrl ? (
            <img src={ad.imageUrl} alt={ad.title} className="w-full h-full object-cover" />
          ) : (
            <div className="w-full h-full flex items-center justify-center text-muted-foreground">
              No image available
            </div>
          )}
          
          <div className="absolute bottom-0 inset-x-0 h-24 bg-gradient-to-t from-background to-transparent" />
        </div>

        {/* Content */}
        <motion.div 
          initial={{ y: 20, opacity: 0 }}
          animate={{ y: 0, opacity: 1 }}
          className="relative -mt-6 px-6 pb-32"
        >
          <div className="bg-background rounded-3xl p-6 shadow-[0_-10px_40px_rgba(0,0,0,0.05)] border border-border/50 mb-6">
            <div className="flex justify-between items-start gap-4 mb-4">
              <h1 className="font-display text-2xl font-extrabold leading-tight">
                {ad.title}
              </h1>
              <span className="font-display text-2xl font-black text-primary shrink-0">
                ${Number(ad.price).toLocaleString()}
              </span>
            </div>

            <div className="flex flex-wrap gap-4 text-sm text-muted-foreground mb-6 border-b border-border/50 pb-6">
              <div className="flex items-center gap-1.5 bg-secondary px-3 py-1.5 rounded-lg">
                <MapPin className="w-4 h-4" /> {ad.location}
              </div>
              <div className="flex items-center gap-1.5 bg-secondary px-3 py-1.5 rounded-lg">
                <Tag className="w-4 h-4" /> {ad.category}
              </div>
            </div>

            <div className="mb-6">
              <h3 className="font-display font-bold text-lg mb-3">Description</h3>
              <p className="text-foreground/80 leading-relaxed whitespace-pre-wrap">
                {ad.description}
              </p>
            </div>

            <div className="flex items-center gap-4 pt-6 border-t border-border/50">
              <div className="w-12 h-12 bg-primary/10 text-primary rounded-full flex items-center justify-center font-display font-bold text-lg">
                {ad.user?.username?.charAt(0).toUpperCase() || 'U'}
              </div>
              <div>
                <p className="font-bold">{ad.user?.username || 'Unknown User'}</p>
                <p className="text-xs text-muted-foreground">
                  Posted {ad.createdAt ? formatDistanceToNow(new Date(ad.createdAt)) : 'recently'} ago
                </p>
              </div>
            </div>
          </div>
        </motion.div>

        {/* Fixed Bottom Action */}
        <div className="fixed bottom-0 left-0 right-0 p-6 bg-background/80 backdrop-blur-lg border-t border-border/50 flex justify-center pb-safe">
          <div className="w-full max-w-2xl">
            <Button className="w-full h-14 rounded-2xl text-lg font-bold shadow-lg shadow-primary/25 hover:-translate-y-0.5 transition-all">
              <MessageCircle className="w-5 h-5 mr-2" />
              Contact Seller
            </Button>
          </div>
        </div>
      </div>
    </AppLayout>
  );
}
