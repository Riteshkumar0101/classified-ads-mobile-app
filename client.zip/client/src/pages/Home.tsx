import { useState } from "react";
import { AppLayout } from "@/components/AppLayout";
import { useAds } from "@/hooks/use-ads";
import { AdCard } from "@/components/AdCard";
import { Input } from "@/components/ui/input";
import { Search, MapPin, Loader2 } from "lucide-react";
import { motion } from "framer-motion";

const CATEGORIES = ["All", "Electronics", "Vehicles", "Real Estate", "Furniture", "Services", "Other"];

export default function Home() {
  const [search, setSearch] = useState("");
  const [activeCategory, setActiveCategory] = useState("All");
  
  // Debounce search slightly for better UX
  const { data: ads, isLoading } = useAds(
    search, 
    activeCategory === "All" ? undefined : activeCategory
  );

  return (
    <AppLayout>
      {/* Header section with gradient background */}
      <div className="bg-gradient-to-b from-primary/10 to-background pt-12 pb-6 px-6 rounded-b-[40px]">
        <div className="flex justify-between items-center mb-6">
          <div>
            <p className="text-sm text-muted-foreground flex items-center gap-1 font-medium">
              <MapPin className="w-4 h-4" /> Current Location
            </p>
            <h1 className="font-display text-3xl font-extrabold mt-1 text-foreground tracking-tight">
              Discover
            </h1>
          </div>
          <div className="w-12 h-12 bg-primary/10 rounded-full flex items-center justify-center">
            <span className="text-primary font-bold text-lg font-display">CA</span>
          </div>
        </div>

        {/* Search Bar */}
        <div className="relative relative z-10 group">
          <div className="absolute inset-y-0 left-4 flex items-center pointer-events-none">
            <Search className="h-5 w-5 text-muted-foreground group-focus-within:text-primary transition-colors" />
          </div>
          <Input
            value={search}
            onChange={(e) => setSearch(e.target.value)}
            className="pl-12 h-14 bg-background border-border/50 shadow-lg shadow-black/5 rounded-2xl text-base focus-visible:ring-primary/20"
            placeholder="What are you looking for?"
          />
        </div>
      </div>

      {/* Categories */}
      <div className="px-6 py-4">
        <h2 className="font-display font-bold text-lg mb-4">Categories</h2>
        <div className="flex gap-3 overflow-x-auto no-scrollbar pb-2 -mx-6 px-6">
          {CATEGORIES.map(category => (
            <button
              key={category}
              onClick={() => setActiveCategory(category)}
              className={`px-5 py-2.5 rounded-full whitespace-nowrap text-sm font-semibold transition-all duration-300 shadow-sm ${
                activeCategory === category 
                  ? "bg-foreground text-background shadow-md scale-105" 
                  : "bg-secondary text-secondary-foreground hover:bg-secondary/80"
              }`}
            >
              {category}
            </button>
          ))}
        </div>
      </div>

      {/* Results */}
      <div className="px-6 py-2 flex-1">
        {isLoading ? (
          <div className="flex flex-col items-center justify-center py-20 text-muted-foreground">
            <Loader2 className="w-8 h-8 animate-spin text-primary mb-4" />
            <p>Finding great deals...</p>
          </div>
        ) : ads?.length === 0 ? (
          <div className="flex flex-col items-center justify-center py-20 text-center">
            <div className="w-20 h-20 bg-secondary rounded-full flex items-center justify-center mb-4">
              <Search className="w-10 h-10 text-muted-foreground" />
            </div>
            <h3 className="font-display font-bold text-xl mb-2">No results found</h3>
            <p className="text-muted-foreground max-w-[250px]">
              Try adjusting your search or category filter to find what you're looking for.
            </p>
          </div>
        ) : (
          <motion.div 
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            className="grid grid-cols-1 sm:grid-cols-2 gap-6"
          >
            {ads?.map((ad, idx) => (
              <motion.div
                key={ad.id}
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ delay: idx * 0.05 }}
              >
                <AdCard ad={ad} />
              </motion.div>
            ))}
          </motion.div>
        )}
      </div>
    </AppLayout>
  );
}
