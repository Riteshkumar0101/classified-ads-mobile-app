import { AppLayout } from "@/components/AppLayout";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { z } from "zod";
import { api } from "@shared/routes";
import { useLogin } from "@/hooks/use-auth";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Link } from "wouter";
import { Loader2 } from "lucide-react";
import { motion } from "framer-motion";

const formSchema = api.auth.login.input;
type FormValues = z.infer<typeof formSchema>;

export default function Login() {
  const login = useLogin();
  
  const form = useForm<FormValues>({
    resolver: zodResolver(formSchema),
    defaultValues: { username: "", password: "" }
  });

  return (
    <AppLayout hideNav>
      <div className="flex-1 flex flex-col px-8 pt-20 pb-10">
        <motion.div 
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          className="flex-1 flex flex-col justify-center max-w-sm mx-auto w-full"
        >
          <div className="mb-10 text-center">
            <div className="w-16 h-16 bg-primary text-primary-foreground rounded-2xl flex items-center justify-center mx-auto mb-6 shadow-xl shadow-primary/20 rotate-3">
              <span className="font-display font-bold text-3xl">C</span>
            </div>
            <h1 className="font-display text-3xl font-extrabold tracking-tight mb-2">Welcome Back</h1>
            <p className="text-muted-foreground">Sign in to continue to Classifieds.</p>
          </div>

          <form onSubmit={form.handleSubmit((d) => login.mutate(d))} className="space-y-6">
            <div className="space-y-2">
              <Label htmlFor="username">Username</Label>
              <Input 
                id="username" 
                className="h-14 rounded-xl bg-secondary/50 border-0 focus-visible:ring-primary focus-visible:bg-background transition-all"
                placeholder="Enter your username"
                {...form.register("username")} 
              />
            </div>
            
            <div className="space-y-2">
              <Label htmlFor="password">Password</Label>
              <Input 
                id="password" 
                type="password"
                className="h-14 rounded-xl bg-secondary/50 border-0 focus-visible:ring-primary focus-visible:bg-background transition-all"
                placeholder="••••••••"
                {...form.register("password")} 
              />
            </div>

            <Button 
              type="submit" 
              className="w-full h-14 rounded-xl text-lg font-bold shadow-lg shadow-primary/25 hover:-translate-y-0.5 transition-all mt-4"
              disabled={login.isPending}
            >
              {login.isPending ? <Loader2 className="w-5 h-5 animate-spin mr-2" /> : null}
              Sign In
            </Button>
          </form>

          <p className="text-center mt-8 text-muted-foreground">
            Don't have an account?{" "}
            <Link href="/signup" className="text-primary font-semibold hover:underline">
              Create one
            </Link>
          </p>
        </motion.div>
      </div>
    </AppLayout>
  );
}
