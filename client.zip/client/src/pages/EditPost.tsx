import { AppLayout } from "@/components/AppLayout";
import { AdForm } from "@/components/AdForm";
import { useAd, useUpdateAd } from "@/hooks/use-ads";
import { motion } from "framer-motion";
import { useLocation } from "wouter";
import { ArrowLeft, Loader2 } from "lucide-react";

export default function EditPost({ params }: { params: { id: string } }) {
  const adId = parseInt(params.id);
  const { data: ad, isLoading } = useAd(adId);
  const updateAd = useUpdateAd(adId);
  const [, setLocation] = useLocation();

  const handleSubmit = (data: any) => {
    updateAd.mutate(data, {
      onSuccess: () => setLocation("/my-ads")
    });
  };

  if (isLoading) {
    return (
      <AppLayout>
        <div className="flex items-center justify-center h-[50vh]">
          <Loader2 className="w-8 h-8 animate-spin text-primary" />
        </div>
      </AppLayout>
    );
  }

  if (!ad) return null;

  return (
    <AppLayout>
      <div className="px-6 pt-12 pb-6">
        <div className="flex items-center mb-8 gap-4">
          <button 
            onClick={() => setLocation("/my-ads")}
            className="w-10 h-10 rounded-full bg-secondary flex items-center justify-center hover:bg-secondary/80 transition-colors"
          >
            <ArrowLeft className="w-5 h-5" />
          </button>
          <h1 className="font-display text-2xl font-extrabold tracking-tight">Edit Post</h1>
        </div>

        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
        >
          <AdForm 
            defaultValues={{
              ...ad,
              price: ad.price.toString()
            }}
            onSubmit={handleSubmit} 
            isLoading={updateAd.isPending} 
            submitLabel="Save Changes"
          />
        </motion.div>
      </div>
    </AppLayout>
  );
}
