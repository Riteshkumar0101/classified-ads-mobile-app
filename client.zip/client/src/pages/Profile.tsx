import { AppLayout } from "@/components/AppLayout";
import { useUser, useLogout } from "@/hooks/use-auth";
import { Button } from "@/components/ui/button";
import { User as UserIcon, LogOut, Settings, Shield, Bell } from "lucide-react";
import { motion } from "framer-motion";

export default function Profile() {
  const { data: user } = useUser();
  const logout = useLogout();

  return (
    <AppLayout>
      <div className="bg-primary/5 pt-16 pb-8 px-6 rounded-b-[40px]">
        <div className="flex flex-col items-center text-center">
          <div className="w-24 h-24 bg-background shadow-xl rounded-full flex items-center justify-center mb-4 border-4 border-background">
            <UserIcon className="w-10 h-10 text-primary" />
          </div>
          <h1 className="font-display text-2xl font-extrabold">{user?.username}</h1>
          <p className="text-muted-foreground text-sm mt-1">Joined recently</p>
        </div>
      </div>

      <div className="px-6 py-8">
        <motion.div 
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          className="space-y-4"
        >
          <div className="bg-card rounded-3xl p-2 shadow-sm border border-border/50">
            <button className="w-full flex items-center p-4 hover:bg-secondary rounded-2xl transition-colors">
              <div className="w-10 h-10 bg-secondary rounded-full flex items-center justify-center mr-4">
                <Settings className="w-5 h-5 text-foreground" />
              </div>
              <span className="font-medium text-left flex-1">Account Settings</span>
            </button>
            <button className="w-full flex items-center p-4 hover:bg-secondary rounded-2xl transition-colors">
              <div className="w-10 h-10 bg-secondary rounded-full flex items-center justify-center mr-4">
                <Bell className="w-5 h-5 text-foreground" />
              </div>
              <span className="font-medium text-left flex-1">Notifications</span>
            </button>
            <button className="w-full flex items-center p-4 hover:bg-secondary rounded-2xl transition-colors">
              <div className="w-10 h-10 bg-secondary rounded-full flex items-center justify-center mr-4">
                <Shield className="w-5 h-5 text-foreground" />
              </div>
              <span className="font-medium text-left flex-1">Privacy & Security</span>
            </button>
          </div>

          <Button 
            variant="destructive" 
            className="w-full h-14 rounded-2xl text-lg font-bold bg-destructive/10 text-destructive hover:bg-destructive hover:text-white transition-all shadow-none border border-destructive/20 mt-4"
            onClick={() => logout()}
          >
            <LogOut className="w-5 h-5 mr-2" />
            Log Out
          </Button>
        </motion.div>
      </div>
    </AppLayout>
  );
}
