import { AppLayout } from "@/components/AppLayout";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { z } from "zod";
import { api } from "@shared/routes";
import { useRegister } from "@/hooks/use-auth";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Link } from "wouter";
import { Loader2 } from "lucide-react";
import { motion } from "framer-motion";

const formSchema = api.auth.register.input;
type FormValues = z.infer<typeof formSchema>;

export default function Signup() {
  const register = useRegister();
  
  const form = useForm<FormValues>({
    resolver: zodResolver(formSchema),
    defaultValues: { username: "", password: "" }
  });

  return (
    <AppLayout hideNav>
      <div className="flex-1 flex flex-col px-8 pt-20 pb-10">
        <motion.div 
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          className="flex-1 flex flex-col justify-center max-w-sm mx-auto w-full"
        >
          <div className="mb-10 text-center">
            <h1 className="font-display text-3xl font-extrabold tracking-tight mb-2">Create Account</h1>
            <p className="text-muted-foreground">Join the community to start selling and buying.</p>
          </div>

          <form onSubmit={form.handleSubmit((d) => register.mutate(d))} className="space-y-6">
            <div className="space-y-2">
              <Label htmlFor="username">Username</Label>
              <Input 
                id="username" 
                className="h-14 rounded-xl bg-secondary/50 border-0 focus-visible:ring-primary focus-visible:bg-background transition-all"
                placeholder="Choose a username"
                {...form.register("username")} 
              />
              {form.formState.errors.username && (
                <p className="text-xs text-destructive">{form.formState.errors.username.message}</p>
              )}
            </div>
            
            <div className="space-y-2">
              <Label htmlFor="password">Password</Label>
              <Input 
                id="password" 
                type="password"
                className="h-14 rounded-xl bg-secondary/50 border-0 focus-visible:ring-primary focus-visible:bg-background transition-all"
                placeholder="Create a strong password"
                {...form.register("password")} 
              />
              {form.formState.errors.password && (
                <p className="text-xs text-destructive">{form.formState.errors.password.message}</p>
              )}
            </div>

            <Button 
              type="submit" 
              className="w-full h-14 rounded-xl text-lg font-bold shadow-lg shadow-primary/25 hover:-translate-y-0.5 transition-all mt-4"
              disabled={register.isPending}
            >
              {register.isPending ? <Loader2 className="w-5 h-5 animate-spin mr-2" /> : null}
              Sign Up
            </Button>
          </form>

          <p className="text-center mt-8 text-muted-foreground">
            Already have an account?{" "}
            <Link href="/login" className="text-primary font-semibold hover:underline">
              Sign In
            </Link>
          </p>
        </motion.div>
      </div>
    </AppLayout>
  );
}
