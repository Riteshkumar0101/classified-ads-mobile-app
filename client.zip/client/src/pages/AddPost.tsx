import { AppLayout } from "@/components/AppLayout";
import { AdForm } from "@/components/AdForm";
import { useCreateAd } from "@/hooks/use-ads";
import { motion } from "framer-motion";
import { useLocation } from "wouter";
import { ArrowLeft } from "lucide-react";

export default function AddPost() {
  const createAd = useCreateAd();
  const [, setLocation] = useLocation();

  const handleSubmit = (data: any) => {
    createAd.mutate(data, {
      onSuccess: () => setLocation("/my-ads")
    });
  };

  return (
    <AppLayout>
      <div className="px-6 pt-12 pb-6">
        <div className="flex items-center mb-8 gap-4">
          <button 
            onClick={() => setLocation("/")}
            className="w-10 h-10 rounded-full bg-secondary flex items-center justify-center hover:bg-secondary/80 transition-colors"
          >
            <ArrowLeft className="w-5 h-5" />
          </button>
          <h1 className="font-display text-2xl font-extrabold tracking-tight">Create Post</h1>
        </div>

        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
        >
          <AdForm 
            onSubmit={handleSubmit} 
            isLoading={createAd.isPending} 
            submitLabel="Post Ad"
          />
        </motion.div>
      </div>
    </AppLayout>
  );
}
