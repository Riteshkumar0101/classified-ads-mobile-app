## Packages
framer-motion | Page transitions and animations for a premium app feel

## Notes
Tailwind Config - extend fontFamily:
fontFamily: {
  sans: ["var(--font-sans)"],
  display: ["var(--font-display)"],
}

JWT Token: Stored in localStorage as 'token'. apiRequest and getQueryFn are overridden to attach it automatically.
Images: Handled via base64 string conversion on the client side with a 1MB size limit.
