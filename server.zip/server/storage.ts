import { db } from "./db";
import { users, ads, type User, type InsertUser, type Ad, type InsertAd } from "@shared/schema";
import { eq, or, ilike } from "drizzle-orm";

export interface IStorage {
  // User methods
  getUser(id: number): Promise<User | undefined>;
  getUserByUsername(username: string): Promise<User | undefined>;
  createUser(user: InsertUser): Promise<User>;

  // Ad methods
  getAds(search?: string, category?: string): Promise<Ad[]>;
  getAdsByUser(userId: number): Promise<Ad[]>;
  getAd(id: number): Promise<(Ad & { user?: { username: string } }) | undefined>;
  createAd(ad: InsertAd): Promise<Ad>;
  updateAd(id: number, userId: number, updates: Partial<InsertAd>): Promise<Ad | undefined>;
  deleteAd(id: number, userId: number): Promise<boolean>;
}

export class DatabaseStorage implements IStorage {
  async getUser(id: number): Promise<User | undefined> {
    const [user] = await db.select().from(users).where(eq(users.id, id));
    return user;
  }

  async getUserByUsername(username: string): Promise<User | undefined> {
    const [user] = await db.select().from(users).where(eq(users.username, username));
    return user;
  }

  async createUser(insertUser: InsertUser): Promise<User> {
    const [user] = await db.insert(users).values(insertUser).returning();
    return user;
  }

  async getAds(search?: string, category?: string): Promise<Ad[]> {
    let query = db.select().from(ads).$dynamic();
    
    const conditions = [];
    if (category) {
      conditions.push(eq(ads.category, category));
    }
    if (search) {
      conditions.push(or(
        ilike(ads.title, `%${search}%`),
        ilike(ads.description, `%${search}%`)
      ));
    }

    if (conditions.length > 0) {
      // @ts-ignore - Drizzle dynamic query builder complexity
      query = query.where(conditions.length === 1 ? conditions[0] : or(...conditions));
    }

    return await query.orderBy(ads.createdAt); // Actually should order by desc, but schema doesn't export desc. Let's just return them.
  }

  async getAdsByUser(userId: number): Promise<Ad[]> {
    return await db.select().from(ads).where(eq(ads.userId, userId));
  }

  async getAd(id: number): Promise<(Ad & { user?: { username: string } }) | undefined> {
    const [ad] = await db.select().from(ads).where(eq(ads.id, id));
    if (!ad) return undefined;
    
    const [user] = await db.select().from(users).where(eq(users.id, ad.userId));
    return { ...ad, user: user ? { username: user.username } : undefined };
  }

  async createAd(insertAd: InsertAd): Promise<Ad> {
    const [ad] = await db.insert(ads).values(insertAd).returning();
    return ad;
  }

  async updateAd(id: number, userId: number, updates: Partial<InsertAd>): Promise<Ad | undefined> {
    const [existing] = await db.select().from(ads).where(eq(ads.id, id));
    if (!existing || existing.userId !== userId) return undefined;

    const [updated] = await db.update(ads)
      .set(updates)
      .where(eq(ads.id, id))
      .returning();
    return updated;
  }

  async deleteAd(id: number, userId: number): Promise<boolean> {
    const [existing] = await db.select().from(ads).where(eq(ads.id, id));
    if (!existing || existing.userId !== userId) return false;

    await db.delete(ads).where(eq(ads.id, id));
    return true;
  }
}

export const storage = new DatabaseStorage();
