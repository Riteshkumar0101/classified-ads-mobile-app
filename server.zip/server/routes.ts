import type { Express, Request, Response, NextFunction } from "express";
import { createServer, type Server } from "http";
import { storage } from "./storage";
import { api, errorSchemas } from "@shared/routes";
import { z } from "zod";
import jwt from "jsonwebtoken";

// Use an environment variable or fallback for JWT secret
const JWT_SECRET = process.env.JWT_SECRET || 'super-secret-development-key';

// Middleware to authenticate JWT
const authenticate = (req: Request, res: Response, next: NextFunction) => {
  const authHeader = req.headers.authorization;
  if (!authHeader || !authHeader.startsWith('Bearer ')) {
    return res.status(401).json({ message: 'Unauthorized' });
  }

  const token = authHeader.split(' ')[1];
  try {
    const decoded = jwt.verify(token, JWT_SECRET) as { id: number, username: string };
    // @ts-ignore
    req.user = decoded;
    next();
  } catch (err) {
    return res.status(401).json({ message: 'Invalid token' });
  }
};

export async function registerRoutes(
  httpServer: Server,
  app: Express
): Promise<Server> {
  
  // Auth routes
  app.post(api.auth.register.path, async (req, res) => {
    try {
      const input = api.auth.register.input.parse(req.body);
      const existingUser = await storage.getUserByUsername(input.username);
      if (existingUser) {
        return res.status(400).json({ message: 'Username already exists', field: 'username' });
      }

      // In a real app we would hash the password, skipping for simplicity as requested
      const user = await storage.createUser(input);
      const token = jwt.sign({ id: user.id, username: user.username }, JWT_SECRET, { expiresIn: '7d' });
      
      res.status(201).json({ token, user: { id: user.id, username: user.username } });
    } catch (err) {
      if (err instanceof z.ZodError) {
        return res.status(400).json({
          message: err.errors[0].message,
          field: err.errors[0].path.join('.'),
        });
      }
      res.status(500).json({ message: 'Internal server error' });
    }
  });

  app.post(api.auth.login.path, async (req, res) => {
    try {
      const input = api.auth.login.input.parse(req.body);
      const user = await storage.getUserByUsername(input.username);
      
      if (!user || user.password !== input.password) {
        return res.status(401).json({ message: 'Invalid credentials' });
      }

      const token = jwt.sign({ id: user.id, username: user.username }, JWT_SECRET, { expiresIn: '7d' });
      res.status(200).json({ token, user: { id: user.id, username: user.username } });
    } catch (err) {
      if (err instanceof z.ZodError) {
        return res.status(400).json({
          message: err.errors[0].message,
          field: err.errors[0].path.join('.'),
        });
      }
      res.status(500).json({ message: 'Internal server error' });
    }
  });

  app.get(api.auth.me.path, authenticate, (req, res) => {
    // @ts-ignore
    res.status(200).json(req.user);
  });

  // Ads routes
  app.get(api.ads.list.path, async (req, res) => {
    try {
      // Create a dummy object to parse query params (in a real app you'd parse from req.query)
      const search = req.query.search as string | undefined;
      const category = req.query.category as string | undefined;
      
      const ads = await storage.getAds(search, category);
      res.status(200).json(ads);
    } catch (err) {
      res.status(500).json({ message: 'Internal server error' });
    }
  });

  app.get(api.ads.myAds.path, authenticate, async (req, res) => {
    try {
      // @ts-ignore
      const userId = req.user.id;
      const ads = await storage.getAdsByUser(userId);
      res.status(200).json(ads);
    } catch (err) {
      res.status(500).json({ message: 'Internal server error' });
    }
  });

  app.get(api.ads.get.path, async (req, res) => {
    try {
      const ad = await storage.getAd(Number(req.params.id));
      if (!ad) {
        return res.status(404).json({ message: 'Ad not found' });
      }
      res.status(200).json(ad);
    } catch (err) {
      res.status(500).json({ message: 'Internal server error' });
    }
  });

  app.post(api.ads.create.path, authenticate, async (req, res) => {
    try {
      // @ts-ignore
      const userId = req.user.id;
      const input = api.ads.create.input.parse(req.body);
      
      const ad = await storage.createAd({
        ...input,
        userId,
      });
      res.status(201).json(ad);
    } catch (err) {
      if (err instanceof z.ZodError) {
        return res.status(400).json({
          message: err.errors[0].message,
          field: err.errors[0].path.join('.'),
        });
      }
      res.status(500).json({ message: 'Internal server error' });
    }
  });

  app.put(api.ads.update.path, authenticate, async (req, res) => {
    try {
      // @ts-ignore
      const userId = req.user.id;
      const input = api.ads.update.input.parse(req.body);
      
      const ad = await storage.updateAd(Number(req.params.id), userId, input);
      if (!ad) {
        return res.status(404).json({ message: 'Ad not found or you are not authorized' });
      }
      res.status(200).json(ad);
    } catch (err) {
      if (err instanceof z.ZodError) {
        return res.status(400).json({
          message: err.errors[0].message,
          field: err.errors[0].path.join('.'),
        });
      }
      res.status(500).json({ message: 'Internal server error' });
    }
  });

  app.delete(api.ads.delete.path, authenticate, async (req, res) => {
    try {
      // @ts-ignore
      const userId = req.user.id;
      const success = await storage.deleteAd(Number(req.params.id), userId);
      
      if (!success) {
        return res.status(404).json({ message: 'Ad not found or you are not authorized' });
      }
      res.status(204).end();
    } catch (err) {
      res.status(500).json({ message: 'Internal server error' });
    }
  });

  // Seed the database with sample data
  async function seedDatabase() {
    try {
      const users = await storage.getAds(); // Just using this to check if DB is empty
      if (users.length === 0) {
        const dummyUser = await storage.createUser({
          username: "testuser",
          password: "password123"
        });

        await storage.createAd({
          title: "iPhone 13 Pro Max",
          description: "Excellent condition, used for 1 year. Comes with box and charger.",
          price: "699",
          category: "Electronics",
          location: "New York, NY",
          imageUrl: "https://images.unsplash.com/photo-1632661674596-df8be070a5c5?auto=format&fit=crop&q=80&w=600",
          userId: dummyUser.id,
        });

        await storage.createAd({
          title: "Mountain Bike",
          description: "Hardly used mountain bike, 21 gears, perfect for trails.",
          price: "250",
          category: "Sports",
          location: "Denver, CO",
          imageUrl: "https://images.unsplash.com/photo-1532298229144-0ec0c57515c7?auto=format&fit=crop&q=80&w=600",
          userId: dummyUser.id,
        });

        await storage.createAd({
          title: "Wooden Dining Table",
          description: "Solid oak dining table. Seats 6 people comfortably.",
          price: "150",
          category: "Furniture",
          location: "Austin, TX",
          imageUrl: "https://images.unsplash.com/photo-1530018607912-eff2daa1bac4?auto=format&fit=crop&q=80&w=600",
          userId: dummyUser.id,
        });
      }
    } catch (e) {
      console.error("Failed to seed database:", e);
    }
  }

  // Run seed function non-blockingly
  seedDatabase();

  return httpServer;
}
